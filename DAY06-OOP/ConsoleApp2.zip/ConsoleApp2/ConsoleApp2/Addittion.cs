namespace ConsoleApp2;

public static class Addittion
{
    public static int AddNumbers(int a, int b)
    {
        return a + b; 
    }

    public static double AddNumbers(double a, double b)
    {
        return a + b; 
    }
    
    
}