﻿// See https://aka.ms/new-console-template for more information


using ConsoleApp5.Presentation;

ManageEmployee manageEmployee = new ManageEmployee();
manageEmployee.Run();