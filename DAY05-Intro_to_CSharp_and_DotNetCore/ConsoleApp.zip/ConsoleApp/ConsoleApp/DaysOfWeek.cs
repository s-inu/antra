namespace ConsoleApp;

public enum DaysOfWeek
{
    Sunday = 4, 
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday
}