﻿

using ConsoleApp3;
using ConsoleApp3.Presentation;

// Console.WriteLine(GenericDemo.AreEqual(12, 2));
//
// Console.WriteLine(GenericDemo.AreEqual(12.33, 2.444));
//
// Console.WriteLine(GenericDemo.AreEqual("hello", "hello"));
//
//
// Console.WriteLine(GenericDemo.AreEqual("hello", 12));

 //Console.WriteLine(GenericDemo<int>.AreEqual(1,2));
// Console.WriteLine(GenericDemo<double>.AreEqual(1.343,2.4324));
// Console.WriteLine(GenericDemo<int>.AreEqual(2,2));
// Console.WriteLine(GenericDemo<string>.AreEqual("helllo world","hi"));

ManageCustomer manageCustomer = new ManageCustomer();
manageCustomer.Run();