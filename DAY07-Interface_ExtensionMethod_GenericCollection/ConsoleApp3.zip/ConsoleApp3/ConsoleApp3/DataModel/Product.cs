namespace ConsoleApp3.DataModel;

public class Product
{
    public int ProductId { get; set; }
    public string ProducName{ get; set; }
    public decimal Price { get; set; }
}