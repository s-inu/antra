namespace ConsoleApp3.DataModel;

public class Category
{
    
}